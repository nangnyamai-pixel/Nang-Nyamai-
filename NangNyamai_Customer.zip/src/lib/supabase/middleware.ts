import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import type { Database } from "@/types/database";

/**
 * Refreshes the Supabase auth session on every request and applies
 * coarse route protection for /staff and /admin.
 *
 * This is a first line of defense only. It must NOT be relied on as the
 * sole authorization mechanism — every sensitive read/write also needs
 * Row Level Security policies and server-side role checks, since
 * middleware/route checks can be bypassed by calling APIs directly.
 */
export async function updateSession(request: NextRequest) {
  const publishableKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  let supabaseResponse = NextResponse.next({ request });

  const supabase = createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    publishableKey!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          );
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  const isStaffLogin = path === "/staff/login";
  const isStaffRoute = path.startsWith("/staff") && !isStaffLogin;
  const isAdminRoute = path.startsWith("/admin");

  if ((isStaffRoute || isAdminRoute) && !user) {
    const redirectUrl = request.nextUrl.clone();
    redirectUrl.pathname = isStaffRoute ? "/staff/login" : "/auth/login";
    redirectUrl.searchParams.set("redirectTo", path);
    return NextResponse.redirect(redirectUrl);
  }

  if (isStaffLogin && user) {
    const { data: staff } = await supabase
      .from("staff_profiles")
      .select("is_active")
      .eq("auth_user_id", user.id)
      .eq("is_active", true)
      .maybeSingle();

    if (staff) {
      const redirectUrl = request.nextUrl.clone();
      redirectUrl.pathname = "/staff/orders";
      redirectUrl.search = "";
      return NextResponse.redirect(redirectUrl);
    }
  }

  // Role-based checks (staff vs admin) happen in lib/auth using the
  // authenticated user's profile — see lib/auth/roles.ts.

  return supabaseResponse;
}
