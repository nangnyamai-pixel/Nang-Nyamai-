import { redirect } from "next/navigation";

export default function HomePage() {
  redirect("/order?table=T12");
}
