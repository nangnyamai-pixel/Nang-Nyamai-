# NangNyamai Local Version Information

1. Developer/module: NangNyamai complete current local project; customer, staff and admin modules included.
2. Current branch: main
3. Current commit: a0429e8b3c44dc2870caf3a1218728646ddfda5c
4. Uncommitted changes: Yes — 23 porcelain entries at backup time. No commit, push, pull or reset was performed for this backup.
5. Main features implemented: Customer menu/order flow, QR table context, cart and checkout, customer profile, feedback, AI Food Match, Smart Cart updates, staff order queue/kitchen/payment/receipt workflows, admin entry point, Supabase integration, theme/language support.
6. Features currently working: Customer menu and food details, add/quantity/remove cart, checkout/order API, order tracking, profile, AI Food Match API/UI, feedback API/UI, staff routes and receipt components, auth routes, Supabase server/client utilities.
7. Known issues: Working tree contains uncommitted local changes; Popular/Recommended badge visibility depends on current menu/order data and runtime configuration; production Supabase/RLS state must be verified separately; no automated test script is defined in package.json.
8. Important files: src/app/(customer)/order/page.tsx; src/components/customer/menu-browser.tsx; src/components/customer/food-card.tsx; src/components/customer/food-match.tsx; src/lib/food-match.ts; src/app/api/orders/route.ts; src/app/api/ai-food-match/; src/app/api/feedback/; src/components/staff/; src/app/admin/page.tsx; src/lib/supabase/; supabase/.
9. Database/Supabase dependencies: Supabase Auth, Data API, PostgreSQL tables for profiles, restaurant_tables, categories, menu_items, orders, order_items, feedback and ai_food_matches; SQL/migrations in supabase/ are included.
10. Environment variables required: See .env.example. Local secrets in .env.local were intentionally excluded from this ZIP.
11. How to run locally: npm install; configure variables from .env.example in a local .env.local; npm run dev; for phone/LAN testing use npm run dev -- --hostname 0.0.0.0. Validation commands: npm run lint; npm exec tsc -- --noEmit --incremental false; npm run build.

## Inventory
- Customer modules: menu, categories, food cards/details, cart, checkout, order confirmation/tracking, profile, feedback, AI Food Match, Smart Cart, language/theme controls.
- Staff modules: authenticated staff layout, order queue, order details/status, kitchen notifications, payments, completion and digital receipt.
- Admin modules: admin route and role/auth utilities.
- Shared: UI Button, Badge, Card, Input, category icon, customer/shared controls, theme and i18n providers.
- Routes/pages: /, /order, /order/[id], /order/[id]/feedback, /profile, /auth/login, /auth/callback, /admin, /staff and staff authenticated subroutes, API routes under src/app/api/.
- Database/Supabase: supabase/sql, supabase/seed.sql, supabase/migrations, src/types/database.ts, src/lib/supabase/.
- Authentication: Supabase browser/server clients, auth callback/login, role helpers, staff session routes.
- API/services: orders, profile, feedback, AI Food Match, staff login/session/payment APIs.
- AI: rule-based food matching in src/lib/food-match.ts, AI activity and personalization routes.
- QR/table: table/token query parameters, restaurant_tables validation in orders API.
- Cart/checkout/orders: MenuBrowser state, QuantitySelector, OrderSummary, /api/orders, order tracking and receipts.
- Assets/CSS/config: public/ food images and icons, src/app/globals.css, next.config.ts, postcss.config.mjs, package.json, package-lock.json, tsconfig.json, eslint.config.mjs.
- PWA/configuration: Next.js App Router configuration; no separate vite.config, tailwind.config or index.html was present at backup time.
